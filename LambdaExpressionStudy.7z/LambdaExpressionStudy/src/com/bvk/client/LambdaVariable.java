package com.bvk.client;

import java.util.Scanner;

import com.bvk.entity.Square;

public class LambdaVariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		int sq = 0;
		
		Scanner scInput = new Scanner(System.in);
		System.out.print("Enter a number: ");
		number = scInput.nextInt();
		
/*		Square sqr = new Square(){
			public int square(){
				return number * number;
			}
		};*/
		Square square = () -> number * number;
		sq = square.square();
		
		System.out.println(sq);
		
		scInput.close();
	}
}