package com.bvk.entity;

import com.bvk.exception.EmptyArrayException;

public interface AddArray {
	public double sumArray(double numbers[])throws EmptyArrayException;
}