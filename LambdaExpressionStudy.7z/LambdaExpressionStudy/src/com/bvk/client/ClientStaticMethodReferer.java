package com.bvk.client;

import com.bvk.entity.StringOperation;
import com.bvk.entity.StringTask;

public class ClientStaticMethodReferer {
	public static String stringOp(StringTask st, String s){
		return st.func(s);
	}
	
	public static void main(String[] args) {
		String original = "Lambda expressions add power to Java.";
		String reversed = null;
		
		System.out.println("Original: " + original);
		reversed = stringOp(StringOperation::reverse, original);
		
		System.out.println("Reversed: " + reversed);
	}
}