package com.bvk.entity;

public class CheckEvenImpl implements CheckEven {

	@Override
	public boolean isEven(int number) {
		boolean isItEven;
		isItEven = number % 2 == 0;
		return isItEven;
	}

}
