package com.bvk.entity;

public interface StringFunc {
	String func(String n);
}