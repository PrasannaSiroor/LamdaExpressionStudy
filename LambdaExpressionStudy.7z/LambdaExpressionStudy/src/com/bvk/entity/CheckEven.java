package com.bvk.entity;

public interface CheckEven {
	boolean isEven(int number);
}