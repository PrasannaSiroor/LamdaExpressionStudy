package com.bvk.entity;

public class StringOperation {
	public static String reverse(String n){
		String reversed = null;
		
		StringBuffer sbf = new StringBuffer(n);
		sbf.reverse();
		reversed = new String(sbf);
		
		return reversed;
	}
}